package org.cvtc.shapes.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.cvtc.shapes.Cylinder;
import org.junit.Test;

public class CylinderTest {
	
	MessageBoxSub message = new MessageBoxSub();


	Cylinder cylinder1 = new Cylinder(message,1,1);
	Cylinder cylinder2;

		
	@Test
	public void testConstructor() {
	cylinder2 = new Cylinder(message, 1, 1);
			
	assertTrue(cylinder2 instanceof Cylinder);
	}
			
		@Test
		public void testGetRadius() {
			assertEquals(1.0, cylinder1.getRadius(), 0.0);
		}

		@Test
		public void testGetHeight() {
			assertEquals(1.0, cylinder1.getHeight(), 0.0);
		}
		
		@Test
		public void testGetSurfaceArea() {
			assertEquals(1.0, cylinder1.surfaceArea(),12.566);
			assertNotEquals(8.0, cylinder1.surfaceArea(), 0.0);
			assertNotEquals(-1.0, cylinder1.surfaceArea(), 0.0);
		}
		
		@Test
		public void testGetVolume() {
			assertEquals(1.0, cylinder1.volume(), 3.141);
			assertNotEquals(10.0, cylinder1.volume(), 0.0);
			assertNotEquals(-1.0, cylinder1.volume(), 0.0);
		}
		
		@Test
		public void testRenderOne() {
			cylinder1.render();
		}
		
		@Test
		public void testRenderTwo() {
			cylinder2.render();
		}
		
		
}
