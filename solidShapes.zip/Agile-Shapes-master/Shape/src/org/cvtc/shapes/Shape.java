package org.cvtc.shapes;

public abstract class Shape {
	
	private Dialog messageBox;

	protected Dialog getMessagebox() {
		return this.messageBox;
	}
	
	public void setMessageBox(Dialog messageBox) {
		this.messageBox = messageBox;
	}

	
	public Shape(Dialog messageBox) {
		setMessageBox(messageBox);
	}
	
	abstract float surfaceArea();
	
	abstract float volume();

}
