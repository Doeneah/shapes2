package org.cvtc.shapes;

import javax.swing.JOptionPane;

public class Cylinder extends Shape {
	
	// Variables
	private float radius = 0;
	private float height = 0;
	final double PI = Math.PI;
	
	// Overlaoded constructor
	public Cylinder(float radius, float height) {
		super();
		this.radius = radius;
		this.height = height;
	}

	// getters and setters
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	// Override functions
	@Override
	public float surfaceArea() {
		return (float) (2 * PI * Math.pow(radius, 2) + 2 * PI * radius * height);
	}

	@Override
	public float volume() {
		return (float) (PI * Math.pow(radius, 2) * height);
	}

	@Override
	public void render() {
		JOptionPane.showMessageDialog(null, "Cylinder radius: " + radius +
				"\nCylinder Height: " + height +
				"\n Cylinder Surface Area: " + surfaceArea() + 
				"\n Cylinder Volume: " + volume());
	}

	
	
	
}
