package org.cvtc.shapes;

import javax.swing.JOptionPane;

public class Sphere extends Shape {

	// cariables
	private float radius = 0;
	final double PI = Math.PI;

	// Overloaded constructor
	public Sphere(float radius) {
		super();
		this.radius = radius;
	}

	// Getters and setters
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	// Override functions
	@Override
	public float surfaceArea() {
		return (float) (4 * PI * Math.pow(radius, 2));
	}

	@Override
	public float volume() {
		return (float) (1.3333 * Math.PI *  Math.pow(radius, 3));
	}

	@Override
	public void render() {
		JOptionPane.showMessageDialog(null, "Sphere radius: " + radius +
				"\nSphere Surface Area: " + surfaceArea() + 
				"\nSphere Volume: " + volume());
	}

	
}
