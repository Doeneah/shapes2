package org.cvtc.shapes;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class ShapesTest {

	public static void main(String[] args) {
		
		//variables
		float width, cubeHeight, depth, 
				cylRad, cylHeight, 
				sphereRad;
		
		//opens keyboard for user input
		Scanner keyboard = new Scanner(System.in);
		
		// User input for cube
		System.out.println("What is the width of the cube? ");
		width = keyboard.nextFloat();
		System.out.println("What is the height of the cube? ");
		cubeHeight = keyboard.nextFloat();
		System.out.println("What is the depth of the cube? ");
		depth = keyboard.nextFloat();
		
		// User input for Cylinder
		System.out.println("What is the radius of the cylinder? ");
		cylRad = keyboard.nextFloat();
		System.out.println("What is the height of the cylinder? ");
		cylHeight = keyboard.nextFloat();
		
		// User input for sphere
		System.out.println("What is the radius of the sphere? ");
		sphereRad = keyboard.nextFloat();
		
		// closes keyboard
		keyboard.close();
		
		// Cube object. Checks if it is negative then displays the information
		if (width <= 0 || cubeHeight <= 0 || depth <= 0) {
			JOptionPane.showMessageDialog(null, "You numbers for the cube was negative or 0. Please enter a valid number");
		} else {
			Shape cube = new Cuboid(width, cubeHeight, depth);
			cube.render();
		}
		
		// Cylinder object. Checks if it is negative then displays the information
		if(cylRad <= 0 || cylHeight <= 0 ) {
			JOptionPane.showMessageDialog(null, "You numbers for the cylinder was negative or 0. Please enter a valid number");
		} else {
			Shape cylinder = new Cylinder(cylRad, cylHeight);
			cylinder.render();
		}
		
		// Sphere object. Checks if it is negative then displays the information
		if (sphereRad <= 0) {
			JOptionPane.showMessageDialog(null, "You numbers for the sphere was negative or 0. Please enter a valid number");
		} else {
			Shape sphere = new Sphere(sphereRad);
			sphere.render();
		}

		
	}
	

}

