package org.cvtc.shapes;

import javax.swing.JOptionPane;

public class Cuboid extends Shape {

	// variables
	private float width = 0;
	private float height = 0;
	private float depth = 0;
	
	// Overloaded constructor
	public Cuboid(float width, float height, float depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}

	// Getters and setters
	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getDepth() {
		return depth;
	}

	public void setDepth(float depth) {
		this.depth = depth;
	}

	// Override functions
	@Override
	public float surfaceArea() {
		return (width * height + width * depth + height * depth) * 2;
	}

	@Override
	public float volume() {
		return depth * width * height;
	}

	@Override
	public void render() {
		JOptionPane.showMessageDialog(null, "Cube width: " + width +
				"\nCube Height: " + height +
				"\nCube depth: " + depth +
				"\nCube Surface area: " + surfaceArea() +
				"\nCube Volume: " + volume());
		
	}
	

	
	
	
}
