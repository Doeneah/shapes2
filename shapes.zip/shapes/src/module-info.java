/**
 * 
 */
/**
 * @author doeneahmcintyre
 *
 */
module shapes {
	requires java.desktop;
}