package org.cvtc.shapes.test;

import static org.junit.Assert.*;

import org.cvtc.shapes.Cuboid;
import org.junit.Test;

public class CuboidTest {
	
	
	MessageBoxSub message = new MessageBoxSub();

	Cuboid cube1 = new Cuboid(message, 1,1,1);
	Cuboid cube2;

	
	@Test
	public void testConstructor() {
		cube2 = new Cuboid(message, 1, 1, 1);
		
		assertTrue(cube2 instanceof Cuboid);
	}
		
	@Test
	public void testGetWidth() {
		assertEquals(1.0, cube1.getWidth(), 0.0);
	}

	@Test
	public void testGetHeight() {
		assertEquals(1.0, cube1.getHeight(), 0.0);
	}
	
	@Test
	public void testGetSurfaceArea() {
		assertEquals(6.0, cube1.surfaceArea(), 0);
		assertNotEquals(0.0, cube1.surfaceArea(), 0);
		assertNotEquals(-1.0, cube1.surfaceArea(), 0);
		
	}
	
	@Test
	public void testGetVolume() {
		assertEquals(1.0, cube1.volume(), 0.0);
		assertNotEquals(0.0, cube1.volume(), 0.0);
		assertNotEquals(-1.0, cube1.volume(), 0.0);
	}
	
	@Test
	public void testRenderOne() {
		cube1.render();
	}
	
	@Test
	public void testRenderTwo() {
		cube2.render();
	}
	
}
