package org.cvtc.shapes.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;


import org.cvtc.shapes.Sphere;
import org.junit.Test;

public class SphereTest {

	MessageBoxSub message = new MessageBoxSub();
	
	Sphere sphere1 = new Sphere(message, 1);
	Sphere sphere2;

	
	@Test
	public void testConstructor() {
		sphere2 = new Sphere(message, 1);
		
		assertTrue(sphere2 instanceof Sphere);
	}
		
	@Test
	public void testGetRadius() {
		assertEquals(1.0, sphere1.getRadius(), 0.0);
	}

	@Test
	public void testGetSurfaceArea() {
		assertEquals(1.0, sphere1.surfaceArea(), 12.566);
		assertNotEquals(8.0, sphere1.surfaceArea(), 0.0);
		assertNotEquals(-1.0, sphere1.surfaceArea(), 0.0);
	}
	
	@Test
	public void testGetVolume() {
		assertEquals(1.0, sphere1.volume(), 4.188);
		assertNotEquals(10.0, sphere1.volume(), 0.0);
		assertNotEquals(-1.0, sphere1.volume(), 0.0);
		
	}
	
	@Test
	public void testRenderOne() {
		sphere1.render();
	}
	
	@Test
	public void testRenderTwo() {
		sphere2.render();
	}

}
