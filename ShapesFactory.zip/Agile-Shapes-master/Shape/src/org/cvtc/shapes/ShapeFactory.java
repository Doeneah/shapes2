package org.cvtc.shapes;

public class ShapeFactory implements Dialog {

	private static Dialog dialog;

	public Dialog getDialog() {
		return dialog;
	}
	
	public ShapeFactory(Dialog dialog) {
		this.dialog = dialog;
	}


	public Shape make(ShapeType type) {
		
		
	      if(type == null){
	          return null;
	       }		
	       if(type == ShapeType.Cuboid){
	          return new Cuboid(dialog, 4, 3, 2);
	          
	       } else if(type == ShapeType.Cylinder){
	          return new Cylinder(dialog, 4, 1);
	          
	       } else if(type == ShapeType.Sphere){
	          return new Sphere(dialog, 5);
	       }
	       
	       return null;
	    }
	
	@Override
	public int show(String message, String title) {
		// TODO Auto-generated method stub
		return 0;
	}


}
