package org.cvtc.shapes;


public class Cylinder extends Shape implements Renderer {
	
	// Variables
	private float radius = 0;
	private float height = 0;
	final double PI = Math.PI;
	
	// Overlaoded constructor
	public Cylinder(Dialog messageBox, float radius, float height) {
		super(messageBox);
		this.radius = radius;
		this.height = height;
	}

	// getters and setters
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	// Override functions
	@Override
	public float surfaceArea() {
		return (float) (2 * PI * Math.pow(radius, 2) + 2 * PI * radius * height);
	}

	@Override
	public float volume() {
		return (float) (PI * Math.pow(radius, 2) * height);
	}

	public void render() {
		
		this.getMessagebox().show("Cylinder radius: " + this.radius +
				"\nCylinder Height: " + this.height +
				"\n Cylinder Surface Area: " + surfaceArea() + 
				"\n Cylinder Volume: " + volume(), null);
	}

	
	
	
}
