package org.cvtc.shapes;

public class Sphere extends Shape implements Renderer {

	// variables
	private float radius = 0;
	final double PI = Math.PI;

	// Overloaded constructor
	public Sphere(Dialog messageBox, float radius) {
		super(messageBox);
		this.radius = radius;
	}

	// Getters and setters
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	// Override functions
	@Override
	public float surfaceArea() {
		return (float) (4 * PI * Math.pow(radius, 2));
	}

	@Override
	public float volume() {
		return (float) (1.3333 * Math.PI *  Math.pow(radius, 3));
	}


	public void render() {
		this.getMessagebox().show("Sphere radius: " + radius +
				"\nSphere Surface Area: " + surfaceArea() + 
				"\nSphere Volume: " + volume(), null);
	}

	
}
